import { Component, ViewChild } from '@angular/core';
import { ElectronService } from 'ngx-electron';
import { MatStepper } from '@angular/material/stepper';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  constructor(
    private _electronService: ElectronService,
    private _snackBar: MatSnackBar
  ) {}

  @ViewChild('stepper') private myStepper: MatStepper;

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  title = 'socket-simulator';
  jsonName = 'selecciona un archivo';
  jsonCount = -1;

  filesParsed = null;
  canStart = false;
  isServerStarted = false;

  angularPath: { html: any; bundle: any } = { html: null, bundle: null };

  onBundleSelected(evt) {
    let files = evt.path[0].files;
    console.log('directory selected: ', files);

    this.angularPath.html = null;
    this.angularPath.bundle = null;

    [...files].forEach((file) => {
      if (file.name === 'index.html') this.angularPath.html = file;
      if (file.name === 'bundle.js') this.angularPath.bundle = file;
    });

    console.log('dist Path: ', this.angularPath);

    if (this.angularPath.html && this.angularPath.bundle) {
      this.nextStep();
    } else {
      this.openSnackBar('ERROR: La carpeta no contiene un bundle válido');
    }
  }

  onFileLoaded(fileName) {
    if (fileName != null) {
      this.jsonName = fileName.split('.')[0];
    } else {
      this.jsonName = 'selecciona un archivo';
    }
  }

  onFileParsed(files) {
    console.log('onFileParsed:: ', files);
    if (files != null && files.length != 0) {
      this.filesParsed = files;
      this.nextStep();
    } else {
      this.openSnackBar('ERROR: El archivo no es válido');
    }
  }

  onStart() {
    console.log('onStart');
    this.jsonCount = -1;
    console.log('run-bundle');
    this._electronService.ipcRenderer.send(
      'start-serve-bundle',
      this.angularPath.html.path
    );
    this.isServerStarted = true;
    this.openSnackBar('Servidor iniciado');
  }

  onStop() {
    console.log('onStop');
    this.isServerStarted = false;
    this.jsonCount = -1;
    this._electronService.ipcRenderer.send('stop-serve-bundle');
    this.openSnackBar('Servidor parado');
  }

  sendSocket() {
    if (this.jsonCount < this.filesParsed.length - 1) {
      this.jsonCount++;
      console.log('sendSocket:: ', this.filesParsed[this.jsonCount]);
      this._electronService.ipcRenderer.send(
        'socket-from-angular',
        this.filesParsed[this.jsonCount]
      );
    } else {
      this.openSnackBar('FIN del flujo');
    }
  }

  openBrowser(width, height) {
    console.log('openBrowser', { width, height });
    this._electronService.ipcRenderer.send('open-browser', { width, height });
  }

  openSnackBar(title, content?) {
    this._snackBar.open(title, content, {
      duration: 5000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }

  private nextStep() {
    this.myStepper.selected.completed = true;
    this.myStepper.selected.editable = true;
    this.myStepper.next();
  }
}
