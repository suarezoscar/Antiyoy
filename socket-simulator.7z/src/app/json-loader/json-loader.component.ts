import { Component, OnInit, Output, EventEmitter } from '@angular/core';

const EVENT_BUTTON = 'pushMessageToClient event: button';
const EVENT_ALERT = 'pushMessageToClient event: alert';
const EVENT_KEY = 'pushMessageToClient event: key';
const EVENT_INFO = 'pushMessageToClient event: info';
const EVENT_PREFERENCES = 'pushMessageToClient event: preferences';
const EVENT_CAMBIO_ESTADO = 'pushMessageToClient event: cambioEstado';

@Component({
  selector: 'app-json-loader',
  templateUrl: './json-loader.component.html',
  styleUrls: ['./json-loader.component.scss'],
})
export class JsonLoaderComponent implements OnInit {
  constructor() {}

  @Output() fileLoaded: EventEmitter<any> = new EventEmitter();
  @Output() fileParsed: EventEmitter<any> = new EventEmitter();

  ngOnInit(): void {}

  jsonLoad(event) {
    let file = event.target.files[0];
    if (file != undefined) {
      console.log('fileName ', file.name);
      this.fileLoaded.emit(file.name);
    } else {
      this.fileLoaded.emit(null);
    }

    var reader = new FileReader();
    reader.readAsText(file, 'UTF-8');

    reader.onload = (evt) => {
      console.log('onLoad... ', evt.target.result.toString());

      switch (file.name.split('.')[1]) {
        case 'log':
          this.fileParsed.emit(this.parseLog(evt.target.result.toString()));
          break;

        case 'json':
          this.fileParsed.emit(this.parseJSON(evt.target.result));
          break;
      }
    };

    reader.onerror = function (evt) {
      console.error(evt.target.result);
    };
  }

  parseJSON(jsonLoaded) {
    let jsonToParse = JSON.parse(jsonLoaded);
    console.log('parseJSON:: ', jsonToParse);

    let result = [];

    jsonToParse.forEach((j) => {
      switch (j.socket) {
        case 'key':
          result.push({
            socket: j.socket,
            message: {
              variable: j.variable,
              valor: j.valor,
              atm: j.atm,
            },
          });
          break;

        case 'alert':
          result.push({ socket: j.socket, message: j.data });
          break;

        case 'cambioEstado':
          result.push({ socket: j.socket, message: j.data });
          break;

        default:
          result.push({
            socket: j.socket,
            message: {
              data: j.data,
              tipo: j.tipo,
            },
          });
          break;
      }
    });

    return result;
  }

  parseLog(result: string): Array<Object> {
    let arraySocket = [];

    for (const line of result.split(/[\r\n]+/)) {
      if (line.includes(EVENT_BUTTON)) {
        arraySocket.push({
          socket: 'button',
          message: this.getLogMessage(line),
        });
      } else if (line.includes(EVENT_ALERT)) {
        arraySocket.push({
          socket: 'alert',
          message: this.getLogMessage(line),
        });
      } else if (line.includes(EVENT_KEY)) {
        arraySocket.push({
          socket: 'key',
          message: this.getLogMessage(line),
        });
      } else if (line.includes(EVENT_INFO)) {
        arraySocket.push({
          socket: 'info',
          message: this.getLogMessage(line),
        });
      } else if (line.includes(EVENT_PREFERENCES)) {
        /*  arraySocket.push({
          socket: 'preferences',
          message: this.getLogMessage(line),
        }); */
      } else if (line.includes(EVENT_CAMBIO_ESTADO)) {
        arraySocket.push({
          socket: 'cambioEstado',
          message: this.getLogMessage(line),
        });
      }
    }

    return arraySocket;
  }

  getLogMessage(line: String) {
    let message = line.split(', message: ')[1];

    // TODO: FIX
    if (message.includes('{ "tipo":"DISPOSITIVOS", "data": ')) {
      message += '}';
    }

    try {
      return JSON.parse(message);
    } catch (error) {
      return message;
    }
  }
}
