const { app, BrowserWindow, ipcMain } = require('electron')
const url = require("url");
const path = require("path");
const express = require("express");
const PORT = process.env.PORT || 8000;
var io = null;

let mainWindow
let server

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 760,
        height: 850,
        webPreferences: {
            nodeIntegration: true
        }
    })

    mainWindow.loadURL(
        url.format({
            pathname: path.join(__dirname, `/dist/index.html`),
            protocol: "file:",
            slashes: true
        })
    );
    // Open the DevTools.
    //  mainWindow.webContents.openDevTools()

    // mainWindow.maximize();

    mainWindow.on('closed', function() {
        mainWindow = null
    })

    ipcMain.on('start-serve-bundle', (event, data) => {

        console.log('start-serve-bundle:: ', data);

        const app = express(),
            DIST_DIR = data.replace('index.html', ''),
            HTML_FILE = data
        app.use(express.static(DIST_DIR))
        app.get('*', (req, res) => {
            res.sendFile(HTML_FILE)
        })

        server = app.listen(PORT, () => {
            console.log(`App listening to ${PORT}....`)
            console.log('Press Ctrl+C to quit.')

            console.log('starting socketIO');

            const socketServer = require('http').createServer(app);
            io = require('socket.io')(socketServer);

            io.on('connection', client => {
                console.log('send wellcome to client ', client);

                io.emit('wellcome');

                client.on('ackClient', data => io.emit('ackServer'))

                client.on('event', data => { console.log('event', data) });

                client.on('disconnect', () => {
                    console.log('client disconnected');
                    io.close();
                });
            });
            io.listen(8090);


            ipcMain.on('socket-from-angular', (event, data) => {
                console.log('socket from angular: ', data);
                io.emit(data.socket, data.message);
            });

        })

    });


    ipcMain.on('stop-serve-bundle', (event, data) => {
        console.log('stop-serve-bundle:: ', event, data);
        if (io != null)
            io.close();

        server.close(function() { console.log('Doh :('); });
    });


    ipcMain.on('open-browser', (event, data) => {
        const { width, height } = data;
        win = new BrowserWindow({ width, height, resizable: false })

        win.loadURL(`http://localhost:${PORT}/#/`)
        win.openDevTools({ detached: true })
    })

}

app.on('ready', createWindow)

app.on('window-all-closed', function() {
    if (process.platform !== 'darwin') app.quit()
})

app.on('activate', function() {
    if (mainWindow === null) createWindow()
})